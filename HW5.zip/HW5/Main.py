
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mlxtend.plotting import scatterplotmatrix
from mlxtend.plotting import heatmap
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import RANSACRegressor
from sklearn.model_selection import train_test_split
import scipy as sp
import seaborn as sns
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import Lasso
from sklearn.linear_model import Ridge
from sklearn.linear_model import ElasticNet
from sklearn.preprocessing import PolynomialFeatures
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.datasets import fetch_california_housing 
from sklearn.datasets import make_regression
import time

#California Housing dataset
CA_housing = fetch_california_housing(as_frame=True)
print('CA_housing feature names:', CA_housing.feature_names)
df_all = CA_housing.frame
df_all = df_all.rename(columns = {'MedHouseVal': 'MEDV'})
df = df_all.iloc[:1000]
print('df.info:', df.info)

cols = ['MedInc', 'HouseAge', 'AveRooms', 'AveBedrms', 'MEDV']
correlation_coefficient = np.corrcoef(df[cols].values.T)
print(correlation_coefficient)

cols = ['MedInc', 'HouseAge', 'AveRooms', 'AveBedrms', 'MEDV']
sns.pairplot(df[cols],size=2.5)
plt.tight_layout()
plt.show()

cols = ['MedInc', 'HouseAge', 'AveRooms', 'AveBedrms', 'MEDV']
correlation_coefficient = np.corrcoef(df[cols].values.T)
print(correlation_coefficient)

sns.heatmap(correlation_coefficient, annot=True,
yticklabels = cols, xticklabels=cols)
plt.show()

X = df_all[['MedInc', 'HouseAge','AveRooms', 'AveBedrms', 'Population', 'AveOccup', 'Latitude', 'Longitude']].values
y = df_all[['MEDV']].values
sc_x = StandardScaler()
sc_x.fit(X)
X_std = sc_x.transform(X)
sc_y = StandardScaler()
sc_y.fit(y)
y_std = sc_y.transform(y).flatten()
print("y_std flattened: ", type(y_std),y_std.shape)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=0)

# Linear regression 
start_time = time.time()

lr = LinearRegression()
lrmodel_std = LinearRegression()
lrmodel_std.fit(X_std,y_std)
print("Fitting standardized data, slope of lr = %.3f " %lrmodel_std.coef_[0])
print("Fitting standardized data, intercept of lr = %.3f " %lrmodel_std.intercept_)

lr.fit(X_train, y_train)
y_train_pred = lr.predict(X_train)
y_test_pred = lr.predict(X_test)

Xb = np.hstack((np.ones((X.shape[0], 1)), X))
w = np.zeros(X.shape[1])
z = np.linalg.inv(np.dot(Xb.T, Xb))
w = np.dot(z, np.dot(Xb.T, y))

ary = np.array(range(100000))

x,y=make_regression(n_samples=100,n_features=1,n_informative=1,noise = 10,random_state=10)
x_new=np.array([np.ones(len(x)),x.flatten()]).T
theta_best_values=np.linalg.inv(x_new.T.dot(x_new)).dot(x_new.T).dot(y)

x_sample=np.array([[-2],[4]])
 
# Adding x0=1 to each instance.
x_sample_new=np.array([np.ones(len(x_sample)),x_sample.flatten()]).T
  
predict_value=x_sample_new.dot(theta_best_values)
print(predict_value)

# Plot the output.
plt.scatter(x,y,s=30,marker='o')
plt.plot(x_sample,predict_value,c='red')
plt.plot()
plt.xlabel("Feature_1 --->")
plt.ylabel("Target_Variable --->")
plt.title('Simple Linear Regression')
plt.show()


plt.scatter(y_train_pred,  y_train_pred - y_train,
            c='steelblue', marker='o', edgecolor='white',
            label='Training data')
plt.scatter(y_test_pred,  y_test_pred - y_test,
            c='limegreen', marker='s', edgecolor='white',
            label='Test data')
plt.xlabel('Predicted values')
plt.ylabel('Residuals')
plt.legend(loc='upper left')
plt.hlines(y=0, xmin=-10, xmax=50, color='black', lw=2)
plt.xlim([-10, 50])
plt.tight_layout()
plt.show()

print('MSE train for lr: %.3f, test: %.3f' % (
        mean_squared_error(y_train, y_train_pred),
        mean_squared_error(y_test, y_test_pred)))
print('R^2 train for lr: %.3f, test: %.3f' % (
        r2_score(y_train, y_train_pred),
        r2_score(y_test, y_test_pred)))


end_time = time.time()
print('Running Time of Linear Regression:',start_time-end_time)


# Ransac regressor
start_time = time.time()

ransac = RANSACRegressor(LinearRegression(), max_trials=100,
min_samples=50, loss='absolute_loss',
residual_threshold=5.0, random_state=1)


ransac.fit(X_std, y_std)
print('Slope of ransac: %.3f' %ransac.estimator_.coef_[0])
print ('Intercept of ransac: %.3f' %ransac.estimator_ . intercept_ )

print('MSE train for ransac: %.3f, test: %.3f' % (
        mean_squared_error(y_train, y_train_pred),
        mean_squared_error(y_test, y_test_pred)))
print('R^2 trainfor ransac: %.3f, test: %.3f' % (
        r2_score(y_train, y_train_pred),
        r2_score(y_test, y_test_pred)))

end_time = time.time()
print('Running Time of Ransac Regression:',start_time-end_time)

#Lasso regression 
start_time = time.time()

lasso = Lasso(alpha=0.1)
lasso.fit(X_train, y_train)
y_train_pred = lasso.predict(X_train)
y_test_pred = lasso.predict(X_test)
print(lasso.coef_)

print('MSE train for lasso: %.3f, test: %.3f' % (
        mean_squared_error(y_train, y_train_pred),
        mean_squared_error(y_test, y_test_pred)))
print('R^2 trainfor lasso: %.3f, test: %.3f' % (
        r2_score(y_train, y_train_pred),
        r2_score(y_test, y_test_pred)))

end_time = time.time()
print('Running Time of lasso Regression:',start_time-end_time)

# Ridge regression 
start_time = time.time()

rr = Ridge(alpha=0.01)
rr.fit(X_train, y_train) 
pred_train_rr= rr.predict(X_train)
print(rr.coef_)

print('MSE train for ridge: %.3f, test: %.3f' % (
        mean_squared_error(y_train, y_train_pred),
        mean_squared_error(y_test, y_test_pred)))
print('R^2 trainfor ridge: %.3f, test: %.3f' % (
        r2_score(y_train, y_train_pred),
        r2_score(y_test, y_test_pred)))

end_time = time.time()
print('Running Time of Ridge Regression:',start_time-end_time)


#linear

start_time = time.time()

lr_linear = LinearRegression()
lr_linear.fit(X_train,y_train)
y_pred_linear_train = lr_linear.predict(X_train)
y_pred_linear_test = lr_linear.predict(X_test)
r2_linear_train = r2_score(y_train,y_pred_linear_train)
r2_linear_test = r2_score(y_test,y_pred_linear_test)
print("X.shape: ", X.shape)

print('MSE train for linear regression: %.3f, test: %.3f' % (
        mean_squared_error(y_train, y_pred_linear_train),
        mean_squared_error(y_test, y_pred_linear_test)))

#polynomial 2nd degree (quadratic)
quadratic = PolynomialFeatures(degree=2) 
X_train_quadratic = quadratic.fit_transform(X_train)
X_test_quadratic = quadratic.fit_transform(X_test)
lr_quadratic = LinearRegression()
lr_quadratic.fit(X_train_quadratic,y_train)
y_train_quadratic=lr_quadratic.predict(X_train_quadratic) 
y_test_quadratic=lr_quadratic.predict(X_test_quadratic) 
r2_train_quadratic = r2_score(y_train,y_train_quadratic)
r2_test_quadratic = r2_score(y_test,y_test_quadratic)
print("X_quadratic.shape: ", X_train_quadratic.shape)

print('MSE train for linear regression: %.3f, test: %.3f' % (
        mean_squared_error(y_train, y_train_quadratic),
        mean_squared_error(y_test, y_test_quadratic)))

cubic = PolynomialFeatures(degree=3) 
X_train_cubic = cubic.fit_transform(X_train)
X_test_cubic = cubic.fit_transform(X_test)
lr_cubic = LinearRegression() 
lr_cubic.fit(X_train_cubic, y_train)
y_pred_cubic = lr_cubic.predict(X_train_cubic) 
y_test_cubic = lr_cubic.predict(X_test_cubic) 
r2_cubic = r2_score(y_train, y_pred_cubic)
r2_test_cubic = r2_score(y_test,y_test_cubic)
print("X_cubic.shape: ", X_train_cubic.shape)

print('MSE train for linear regression: %.3f, test: %.3f' % (
        mean_squared_error(y_train, y_pred_cubic),
        mean_squared_error(y_test, y_test_cubic)))


print("R^2 linear_train : %.3f , quadratic train %.3f , cubic train: %.3f, linear test: %.3f ,quadratic test %.3f ,cubic test %.3f ," 
%(r2_linear_train , r2_train_quadratic , r2_cubic,r2_linear_test,r2_test_quadratic,r2_test_cubic )) 


end_time = time.time()
print('Running Time of Non Linear Regression:',start_time-end_time)