import pandas as pd
from collections import defaultdict
from time import perf_counter
from scipy.special import comb 
import math
import numpy as np # linear algebra
#import np.random.seed(42)
import pandas as pd 
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.base import BaseEstimator
from sklearn.ensemble import AdaBoostClassifier
from sklearn.model_selection import train_test_split,cross_validate,RepeatedStratifiedKFold
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.svm import SVC 
from sklearn import datasets
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import metrics 
from sklearn.datasets import load_digits

df = pd.read_csv('mammographic_masses.csv',header=None,sep=',',na_values='?')
print(df.isnull().sum())
print(df)
mam = df.replace('?',np.NaN)
mam = df.dropna()
print(mam.isnull().sum())
X = mam.iloc[:,:5]
y=mam.iloc[:,5]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3) 

# Decision tree classifier

tree = DecisionTreeClassifier(criterion='entropy', max_depth=None,random_state=1)
tree = tree.fit(X_train, y_train)
y_train_pred = tree.predict(X_train)
y_test_pred = tree.predict(X_test)
tree_train = accuracy_score(y_train, y_train_pred)
tree_test = accuracy_score(y_test, y_test_pred)
print('Decision tree train/test accuracies %.3f/%.3f'% (tree_train, tree_test))

# Adaboost algorithm 

abc = AdaBoostClassifier(n_estimators=50,learning_rate=1)
# Train Adaboost Classifer
model = abc.fit(X_train, y_train)

#Predict the response for test dataset
y_pred = model.predict(X_test)
tree = tree.fit(X_train, y_train)
y_train_pred = tree.predict(X_train)
y_test_pred = tree.predict(X_test)
ada_train = accuracy_score(y_train, y_train_pred)
ada_test = accuracy_score(y_test, y_test_pred)

print('ADA boost train/test accuracies %.3f/%.3f'% (ada_train, ada_test))

svc = SVC(probability=True, kernel='linear')

abc = AdaBoostClassifier(n_estimators=500, base_estimator=svc,learning_rate=1)

model = abc.fit(X_train, y_train)

y_pred = model.predict(X_test)
print("Accuracy using SVC:",metrics.accuracy_score(y_test, y_pred))


# Bagging classifier algorithm 

bag = BaggingClassifier(base_estimator=tree,n_estimators=100, max_samples=1.0, max_features=1.0, bootstrap=True, bootstrap_features=False, n_jobs=1, random_state=1)
bag = bag.fit(X_train, y_train)
y_train_predi = bag.predict(X_train)
y_test_predi = bag.predict(X_test)
bag_train = accuracy_score(y_train, y_train_predi) 
bag_test = accuracy_score(y_test, y_test_predi) 
print('Bagging train/test accuracies %.3f/%.3f'% (bag_train, bag_test))

forest = RandomForestClassifier(criterion='gini',n_estimators=780, random_state=1,n_jobs=2)
forest.fit(X_train, y_train)
y_train_predict = forest.predict(X_train)
y_test_predict = forest.predict(X_test)
forest_train = accuracy_score(y_train, y_train_predict) 
forest_test = accuracy_score(y_test, y_test_predict) 
print('RandomForest train/test accuracies %.3f/%.3f'% (forest_train, forest_test))