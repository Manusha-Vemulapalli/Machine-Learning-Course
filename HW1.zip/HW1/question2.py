#question 2
import pandas as pd
df = pd.read_csv("iris.csv",header = None, sep=",") #to read a dataset
print(df)
# It basically prints the number of rows and columns in the given dataset.
print("number of rows:", df.shape[0])
print("number of columns:", df.shape[1])
