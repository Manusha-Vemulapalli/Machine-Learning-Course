
#question 1
# importing the pandas package using the import function as shown below.
import pandas as pd
df = pd.read_csv("iris.csv",header = None, sep=",") #to read a dataset
print(df)





