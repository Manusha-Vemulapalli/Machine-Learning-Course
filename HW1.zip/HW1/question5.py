import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df=pd.read_table("iris.csv", header=None, sep=',')

print(df)
#for setosa
fig = df[df[4]== 'Iris-setosa'].plot(kind='scatter', x=0, y=1, color='orange',label='setosa',marker='D')
fig.set_xlabel("Sepal Length")
fig.set_ylabel("Sepal Width")
fig.set_title("Sepal Length VS Width")
fig = plt.gcf()
fig.set_size_inches(12, 8)
plt.show()


fig = df[df[4]== 'Iris-versicolor'].plot(kind='scatter', x=0, y=1, color='green',label='versicolor', marker ='^')
fig.set_xlabel("Sepal Length")
fig.set_ylabel("Sepal Width")
fig.set_title("Sepal Length VS Width")
fig = plt.gcf()
fig.set_size_inches(12, 8)
plt.show()

fig = df[df[4]== 'Iris-virginica'].plot(kind='scatter', x=0, y=1, color='red',label='Iris-virginica', marker ='*')
fig.set_xlabel("Sepal Length")
fig.set_ylabel("Sepal Width")
fig.set_title("Sepal Length VS Width")
fig = plt.gcf()
fig.set_size_inches(12, 8)
plt.show()





