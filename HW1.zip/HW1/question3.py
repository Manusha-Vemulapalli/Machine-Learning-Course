#question 3
import pandas as pd
df = pd.read_csv("iris.csv", header = None, sep = ",")
print(df)
print(df[4])
print(df[4].unique()) # unique refers to the unique value.