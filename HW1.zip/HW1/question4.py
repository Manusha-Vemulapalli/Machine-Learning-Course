import pandas as pd
df = pd.read_csv("iris.csv",header = None, sep=",") #to read a dataset
print(df)
# question 4
print(len(df.loc[df[4] == "Iris-setosa"]))
print(df[0].mean()) # mean to find the average value.
print(df[1].max()) # max function to find the maximum value.
print(df[2].min()) # min function to find the minimum value.
