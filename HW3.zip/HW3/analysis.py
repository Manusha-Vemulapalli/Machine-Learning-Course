from sklearn import datasets
from sklearn.datasets import load_iris
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.preprocessing import StandardScaler
from matplotlib.colors import ListedColormap
from sklearn.metrics import classification_report
from sklearn.datasets import make_classification
from sklearn import svm
from sklearn.svm import SVC
from distutils.version import LooseVersion
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix
import sklearn.metrics as metrics
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
import matplotlib
import random
import pandas as pd
import sklearn.datasets
from sklearn import tree
import time


start = time.time()

class ppn:
    
    iris =load_iris()
    X = iris.data
    y=iris.target
    
    
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=1, stratify=y)
    
    sc = StandardScaler()
    sc.fit(X_train)
    X_train_std = sc.transform(X_train)
    X_test_std = sc.transform(X_test)
    
    
    ppn = Perceptron(max_iter=10,eta0=0.1, random_state=1)
    ppn.fit(X_train_std, y_train)
    
    y_pred = ppn.predict(X_test)
    print('Misclassified examples -digits: %d' % (y_test != y_pred).sum())
    
    
    
    accuracy_ppn = metrics.accuracy_score(y_test,y_pred)
    print('Accuracy for perceptron',accuracy_ppn)
    
end = time.time()
print(f"Runtime of the perceptron is {end - start}")



start = time.time()
class linear:
    
    iris =load_iris()
    X = iris.data
    y=iris.target
    
    
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=1, stratify=y)
    
    sc = StandardScaler()
    sc.fit(X_train)
    X_train_std = sc.transform(X_train)
    X_test_std = sc.transform(X_test)
    
        
    lsvm = svm.SVC(kernel='linear')
    lsvm.fit(X_train_std,y_train)
    score = lsvm.score(X_train,y_train)
    print('Accuracy score for svm ',score)

    
end = time.time()
print(f"Runtime of the linear svm is {end - start}")




start = time.time()
class rbf:
    
    iris =load_iris()
    X = iris.data
    y=iris.target
    
    
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=1, stratify=y)
    
    sc = StandardScaler()
    sc.fit(X_train)
    X_train_std = sc.transform(X_train)
    X_test_std = sc.transform(X_test)
    
        
        
    svm = SVC(kernel='rbf', random_state=1, gamma=0.2, C=1.0)
    svm.fit(X_train_std, y_train)
        
    accuracy_rbf = svm.score(X_train,y_train)
    print('Accuracy score kernelrbf',accuracy_rbf)

    
end = time.time()
print(f"Runtime of the rbf svm is {end - start}")



start = time.time()
class decision_tree:
    
    iris =load_iris()
    X = iris.data
    y=iris.target
    
    
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=1, stratify=y)
    
    sc = StandardScaler()
    sc.fit(X_train)
    X_train_std = sc.transform(X_train)
    X_test_std = sc.transform(X_test)
    
        
        
        
    tree_model = DecisionTreeClassifier(criterion='gini', 
                                            max_depth=4, 
                                            random_state=1)
    
    
    tree_model.fit(X_train_std,y_train)
    
    pred_y=tree_model.predict(X_test)
    
    accuracy_dt = metrics.accuracy_score(y_test,pred_y)
    print("Accuracy for Decision tree:",accuracy_dt)

    tree.plot_tree(tree_model)

    
end = time.time()
print(f"Runtime of the decision tree is {end - start}")

