from sklearn import datasets
from sklearn.datasets import load_digits
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.preprocessing import StandardScaler
from matplotlib.colors import ListedColormap
from sklearn.metrics import classification_report
from sklearn.datasets import make_classification
from sklearn import svm
from sklearn.svm import SVC
from distutils.version import LooseVersion
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix
import sklearn.metrics as metrics
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
import matplotlib
import random
import pandas as pd
from sklearn import tree



digits =load_digits()
X = digits.data
y=digits.target


X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=1, stratify=y)

sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)


ppn = Perceptron(max_iter=10,eta0=0.1, random_state=1)
ppn.fit(X_train_std, y_train)

y_pred = ppn.predict(X_test)
print('Misclassified examples -digits: %d' % (y_test != y_pred).sum())


accuracy_ppn = metrics.accuracy_score(y_test,y_pred)
print('Accuracy for digits',accuracy_ppn)



lsvm = svm.SVC(kernel='linear')
lsvm.fit(X_train_std,y_train)
score = lsvm.score(X_train,y_train)
print('Accuracy score for svm ',score)


svm = SVC(kernel='rbf', random_state=1, gamma=0.2, C=1.0)
svm.fit(X_train_std, y_train)
    
accuracy = svm.score(X_train,y_train)
print('Accuracy score kernelrbf',accuracy)



tree_model = DecisionTreeClassifier(criterion='gini', 
                                        max_depth=4, 
                                        random_state=1)


tree_model.fit(X_train_std,y_train)

pred_y=tree_model.predict(X_test)

accuracy_dt = metrics.accuracy_score(y_test,pred_y)
print("Accuracy for Decision tree:",accuracy_dt)



