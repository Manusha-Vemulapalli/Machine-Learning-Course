Instructions to run the program :

1. Download the zip file. Unzip the file. 
2. The programs are written in the version higher than the 3.9 with .py extension. 
3. The program iris.py is a second question and it is tested using the second dataset.
4. The files can be runned by using the command line 
 python filename.py