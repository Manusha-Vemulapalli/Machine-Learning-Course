from sklearn import datasets
import matplotlib.pyplot as plt 
from sklearn.cluster import KMeans
import numpy as np
from matplotlib import cm
from sklearn.metrics import silhouette_samples, silhouette_score
import pandas as pd
from scipy.cluster import hierarchy
from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import linkage
from scipy.cluster.hierarchy import dendrogram
import sklearn.metrics as sm 
from scipy.cluster.hierarchy import fcluster
from sklearn.cluster import AgglomerativeClustering
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
import time 
import math
import random
import argparse

iris = datasets.load_iris()

x = pd.DataFrame(iris.data, columns=['Sepal Length', 'Sepal Width', 
                                     'Petal Length', 'Petal Width'])
y = pd.DataFrame(iris.target, columns=['Target'])

print(x.shape)
print(np.unique(y))



# K- mean clustering

start_time = time.time()

iris_k_mean_model = KMeans(n_clusters=3)
predict_lab=iris_k_mean_model.fit_predict(x)
print(iris_k_mean_model.labels_)
print(iris_k_mean_model.cluster_centers_)
predictedY = np.choose(iris_k_mean_model.labels_, [0, 1, 2]).astype(np.int64)
print('accuracy score:',sm.accuracy_score(predictedY, y['Target']))
score = silhouette_score(x, predict_lab, metric='euclidean')
print('Silhouette Score: %.3f' % score)

km = KMeans(n_clusters=3, init='random', n_init =10, max_iter=300, tol=1e-04, random_state=0) 
y_km = km.fit_predict(x)
print('Sum squared error : %.3f' %km.inertia_)

end_time = time.time()
print('Time',start_time-end_time)

#elbow

distortions = []
# Calculate distortions
for i in range(1, 11):
    km = KMeans(n_clusters=i, init='k-means++', n_init=10, max_iter=300, random_state=0)
    km.fit(x)
    distortions.append(km.inertia_)
#Plot distortions for different K
plt.plot(range(1, 11), distortions, marker='o')
plt.title('Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('Distortions')
plt.tight_layout()
plt.show()

#scipy

start_time = time.time()

row_cluster1 = linkage(x.values, method='complete', 
metric='euclidean') 
print(row_cluster1)
row_dendr = dendrogram(row_cluster1) 
plt.tight_layout()
plt.ylabel('Euclidean distance') 
plt.show()

k=2
clusters2 = fcluster(row_cluster1, k, criterion='maxclust')
print(clusters2)
score_scipy = silhouette_score(x, clusters2, metric='euclidean')
print('Silhouette Score: %.3f' % score_scipy)

end_time = time.time()
print('Time',start_time-end_time)


# Agglomerative clustering 

start_time = time.time()

cluster1 = AgglomerativeClustering(n_clusters=3,  affinity='euclidean', linkage='complete')
cluster1_labels = cluster1.fit_predict(x)
labels = cluster1.fit_predict(x)
print('Cluster labels: %s' % labels)
score_sklearn = silhouette_score(x, cluster1_labels, metric='euclidean')
print('Silhouette Score: %.3f' % score_sklearn)

end_time = time.time()
print('Time',start_time-end_time)