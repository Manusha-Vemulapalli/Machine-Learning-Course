from sklearn import datasets
import matplotlib.pyplot as plt 
from sklearn.cluster import KMeans
import numpy as np
from matplotlib import cm
from sklearn.metrics import silhouette_samples, silhouette_score
import pandas as pd
from scipy.cluster import hierarchy
from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import linkage
from scipy.cluster.hierarchy import dendrogram
import sklearn.metrics as sm 
from scipy.cluster.hierarchy import fcluster
from sklearn.cluster import AgglomerativeClustering
import time 
from sklearn.datasets import fetch_openml
import random
from random import sample 

mnist = fetch_openml('mnist_784')

x = mnist.data
y = mnist.target
df = pd.DataFrame(x, columns=mnist.feature_names)
df1 = df.sample(100)
df2= y.sample(100)
print(df1)
print(df1.shape)
print(np.unique(y))

# K- mean clustering

start_time = time.time()

iris_k_mean_model = KMeans(n_clusters=10)
predict_lab=iris_k_mean_model.fit_predict(df1)
print(iris_k_mean_model.labels_)
print(iris_k_mean_model.cluster_centers_)
score = silhouette_score(df1, predict_lab, metric='euclidean')
print('Silhouette Score: %.3f' % score)

end_time = time.time()
print('Time',start_time-end_time)


# elbow

distortions = []
# Calculate distortions
for i in range(1, 11):
    km = KMeans(n_clusters=i, init='k-means++', n_init=10, max_iter=300, random_state=0)
    km.fit(x)
    distortions.append(km.inertia_)
#Plot distortions for different K
plt.plot(range(1, 11), distortions, marker='o')
plt.xlabel('Number of clusters')
plt.ylabel('Distortion')
plt.tight_layout()
plt.show()

#scipy

start_time = time.time()

row_cluster1 = linkage(x.values, method='complete', 
metric='euclidean') 
print(row_cluster1)
row_dendr = dendrogram(row_cluster1) 
plt.tight_layout()
plt.ylabel('Euclidean distance') 
plt.show()

k=10
clusters2 = fcluster(row_cluster1, k, criterion='maxclust')
print(clusters2)
score_scipy = silhouette_score(df1, clusters2, metric='euclidean')
print('Silhouette Score: %.3f' % score_scipy)

end_time = time.time()
print('Time',start_time-end_time)

# Agglomerative clustering 

start_time = time.time()

cluster1 = AgglomerativeClustering(n_clusters=10,  affinity='euclidean', linkage='complete')
cluster1_labels = cluster1.fit_predict(df1)
labels = cluster1.fit_predict(df1)
print('Cluster labels: %s' % labels)
score_sklearn = silhouette_score(df1, cluster1_labels, metric='euclidean')
print('Silhouette Score: %.3f' % score_sklearn)

end_time = time.time()
print('Time',start_time-end_time)