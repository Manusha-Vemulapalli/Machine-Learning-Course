from sklearn import datasets
from sklearn.datasets import fetch_openml
from sklearn.datasets import make_blobs
import pandas as pd
import numpy as np
from random import sample
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.decomposition import PCA
from sklearn.tree import DecisionTreeClassifier as Dtree
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.decomposition import KernelPCA as KernelPCA
import time

mist = fetch_openml('mnist_784', version=1)

X= mist.data
y=mist.target

start_time = time.time()
X, y = make_blobs(n_samples=2000)


X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=1, stratify=y)

#standardisation of dataset
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)


tree_model = Dtree(criterion='gini',max_depth=4,random_state=1, max_features=None)

#PCA
pca = PCA(n_components = 2)
X_train_pca = pca.fit_transform(X_train_std)
tree_model.fit(X_train_pca,y_train)
X_test_pca = pca.transform(X_test_std)
y_pred_pca = tree_model.predict(X_test_pca)

print("PCA-shape for MNIST",X_train_pca.shape)

#Accuracy
acc_score_pca = accuracy_score(y_pred_pca,y_test)
print("PCA Accuracy for MNIST",acc_score_pca)
#precision
print('Precision pca for MNIST: ',precision_score(y_test, y_pred_pca,average='weighted'))
#recall
print('Recall for pca for MNIST:',recall_score(y_test, y_pred_pca,average='macro'))
#f1 score
print('F1 Score pca for MNIST:',f1_score(y_test, y_pred_pca,average='macro'))
#metric
print(classification_report(y_test,y_pred_pca))
end_time = time.time()
print('Time',start_time-end_time)

#LDA
start_time = time.time()
X, y = make_blobs(n_samples=2000)


X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=1, stratify=y)

#standardisation of dataset
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

tree_model = Dtree(criterion='gini',max_depth=4,random_state=1, max_features=None)
lda = LDA(n_components=2)
X_train_lda = lda.fit_transform(X_train_std,y_train)
tree_model.fit(X_train_lda,y_train)
X_test_lda = lda.transform(X_test_std)
y_pred_lda = tree_model.predict(X_test_lda)
#shape
print("LDA-shape for MNIST",X_train_lda.shape)

#Accuracy
acc_score_lda = accuracy_score(y_pred_lda,y_test)
print("LDA Accuracy for MNIST",acc_score_lda)
#precision
print('Precision LDA for MNIST: ',precision_score(y_test, y_pred_lda,average='weighted'))
#recall
print('Recall for LDA for MNIST:',recall_score(y_test, y_pred_lda,average='macro'))
#f1 score
print('F1 Score LDA for MNIST:',f1_score(y_test, y_pred_lda,average='macro'))
#metric
print(classification_report(y_test,y_pred_lda))
end_time = time.time()
print('Time',start_time-end_time)

#KCPA

start_time = time.time()
X, y = make_blobs(n_samples=2000)
X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=1, stratify=y)

#standardisation of dataset
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)


kpca = KernelPCA(n_components =2, kernel='rbf',gamma=15)
X_train_kpca = kpca.fit_transform(X_train)
tree_model.fit(X_train_kpca,y_train)
X_test_kpca = kpca.transform(X_test_std)
y_pred_kpca = tree_model.predict(X_test_kpca)
tree_model = Dtree(criterion='gini',max_depth=4,random_state=1, max_features=None)
#shape
print("KPCA-shape for MNIST",X_train_kpca.shape)

#Accuracy
acc_score_kpca = accuracy_score(y_pred_kpca,y_test)
print("KPCA Accuracy for MNIST",acc_score_kpca)
#precision
print('Precision KPCA for MNIST: ',precision_score(y_test, y_pred_lda,average='weighted'))
#recall
print('Recall for KPCA for MNIST:',recall_score(y_test, y_pred_lda,average='macro'))
#f1 score
print('F1 Score KPCA for MNIST:',f1_score(y_test, y_pred_lda,average='macro'))
#metric
print(classification_report(y_test,y_pred_kpca))

end_time = time.time()
print('Time',start_time-end_time)


