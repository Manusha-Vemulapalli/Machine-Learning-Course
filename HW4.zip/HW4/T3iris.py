from sklearn import datasets
import pandas as pd
import numpy as np
from random import sample
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.decomposition import KernelPCA as KernelPCA



iris = datasets.load_iris()
X = iris.data[:, :2]  
y = iris.target

#train and test split
X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=1, stratify=y)

#standardisation
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)


pca = PCA(n_components = 2)
pca.fit(X_train_std)
X_train_pca = pca.transform(X_train_std)
X_test_pca= pca.transform(X_test_std)
print(X_train_pca.shape)


lda = LDA(n_components = 1)
lda.fit(X_train_std,y_train)
X_train_lda = lda.transform(X_train_std)
print(X_train_lda.shape)


kpca = KernelPCA(n_components =1, kernel='rbf',gamma=15)
X_train_kpca = kpca.fit_transform(X_train)
print(X_train_kpca.shape)
