import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.decomposition import KernelPCA as kernelPCA
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier as tree
from sklearn.metrics import accuracy_score as acc
data = load_breast_cancer()

X = data.data
y = data.target


X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=1, stratify=y)

sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)


# decision tree
tree_model = tree(criterion='gini',max_depth=5,random_state=1)

'''PCA'''

#fitting the model
pca = PCA(n_components = 3)
X_train_pca = pca.fit_transform(X_train_std)
tree_model.fit(X_train_pca,y_train)
X_test_pca = pca.transform(X_test_std)
y_pred_pca = tree_model.predict(X_test_pca)

#Accuracy score
acc_score_pca = acc(y_pred_pca,y_test)
print(" PCA Accuracy",acc_score_pca)

#LDA
tree_model_lda = tree(criterion='entropy',max_depth=4,random_state=None,max_features=None)
lda = LDA(n_components=1)
X_train_lda = lda.fit_transform(X_train_std,y_train)
tree_model_lda.fit(X_train_lda,y_train)

X_test_lda = lda.transform(X_test_std)
y_pred_lda = tree_model_lda.predict(X_test_lda)
acc_score_lda = acc(y_pred_lda,y_test)
print("LDA accuracy",acc_score_lda)



#Kenrenl PCA
tree_model_kpca = tree(criterion='gini',max_depth=4,random_state=None,min_samples_leaf=1)
kernelpca = kernelPCA(n_components=2)
X_train_kpca = kernelpca.fit_transform(X_train_std,y_train)
tree_model_kpca.fit(X_train_kpca,y_train)

X_test_kpca = kernelpca.transform(X_test_std)
y_pred_kpca = tree_model_kpca.predict(X_test_kpca)
acc_score_kpca = acc(y_pred_kpca,y_test)
print("KPCA accuracy",acc_score_kpca)
