from sklearn import datasets
from sklearn.datasets import fetch_openml
from sklearn.datasets import make_blobs
import pandas as pd
import numpy as np
from random import sample
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.decomposition import KernelPCA as KernelPCA


mist = fetch_openml('mnist_784', version=1)

X= mist.data
y=mist.target

X, y = make_blobs(n_samples=2000)


X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=1, stratify=y)

#standardisation of dataset
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)


pca = PCA(n_components = 2)
pca.fit(X_train_std)
X_train_pca = pca.transform(X_train_std)
X_test_pca= pca.transform(X_test_std)
print(X_train_pca.shape)


lda = LDA(n_components = 1)
lda.fit(X_train_std,y_train)
X_train_lda = lda.transform(X_train_std)
print(X_train_lda.shape)


kpca = KernelPCA(n_components =1, kernel='rbf',gamma=15)
X_train_kpca = kpca.fit_transform(X_train)
print(X_train_kpca.shape)
