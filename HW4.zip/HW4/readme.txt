Instructions to run the program :

1. Download the zip file. Unzip the file. 
2. The programs are written in the version higher than the 3.9 with .py extension. 
3. The program iris.py is a second question and it is tested using the second dataset.
4. The files can be runned by using the command line 
 python filename.py

Task 1: Question1.py 

Task 2: Question2.py

Task 3: T3iris.py
        T3mnist.py

Task 4: iris.py
        mnist.py

I have taken two datasets and one for each program. I took 2000samples from MNIST dataset. 

Task 4: 

The report which I have mentioned in the report and done in the program as well. 


