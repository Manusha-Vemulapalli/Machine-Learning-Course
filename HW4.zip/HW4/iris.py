from sklearn import datasets
import pandas as pd
import numpy as np
from random import sample
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.decomposition import PCA
from sklearn.tree import DecisionTreeClassifier as Dtree
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.decomposition import KernelPCA as KernelPCA
import time

start_time = time.time()
iris = datasets.load_iris()
X = iris.data[:, :2]  
y = iris.target

#train and test split
X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=1, stratify=y)

#standardisation
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)


tree_model = Dtree(criterion='gini',max_depth=4,random_state=1, max_features=None)

#PCA
pca = PCA(n_components = 2)
X_train_pca = pca.fit_transform(X_train_std)
tree_model.fit(X_train_pca,y_train)
X_test_pca = pca.transform(X_test_std)
y_pred_pca = tree_model.predict(X_test_pca)
print("PCA-shape for iris",X_train_pca.shape)

#Accuracy
acc_score_pca = accuracy_score(y_pred_pca,y_test)
print("PCA Accuracy for iris",acc_score_pca)
#precision
print('Precision pca for iris: ',precision_score(y_test, y_pred_pca,average='weighted'))
#recall
print('Recall for pca for iris:',recall_score(y_test, y_pred_pca,average='macro'))
#f1 score
print('F1 Score pca for iris:',f1_score(y_test, y_pred_pca,average='macro'))

#metric
print(classification_report(y_test,y_pred_pca))
end_time = time.time()
print('Time',start_time-end_time)


#LDA
start_time = time.time()
X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=1, stratify=y)

#standardisation
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)
lda = LDA(n_components=2)

X_train_lda = lda.fit_transform(X_train_std,y_train)
tree_model.fit(X_train_lda,y_train)
X_test_lda = lda.transform(X_test_std)
y_pred_lda = tree_model.predict(X_test_lda)
#shape
print("LDA-shape for iris",X_train_lda.shape)

#Accuracy
acc_score_lda = accuracy_score(y_pred_lda,y_test)
print("LDA Accuracy for iris",acc_score_lda)
#precision
print('Precision LDA for iris: ',precision_score(y_test, y_pred_lda,average='weighted'))
#recall
print('Recall for LDA for iris:',recall_score(y_test, y_pred_lda,average='macro'))
#f1 score
print('F1 Score LDA for iris:',f1_score(y_test, y_pred_lda,average='macro'))
#metric
print(classification_report(y_test,y_pred_lda))
end_time = time.time()
print('Time',start_time-end_time)

#KCPA
start_time=time.time()

X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=1, stratify=y)

#standardisation
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)
lda = LDA(n_components=2)

X_train_lda = lda.fit_transform(X_train_std,y_train)
tree_model.fit(X_train_lda,y_train)
X_test_lda = lda.transform(X_test_std)
y_pred_lda = tree_model.predict(X_test_lda)


kpca = KernelPCA(n_components =2, kernel='rbf',gamma=15)
X_train_kpca = kpca.fit_transform(X_train)
tree_model.fit(X_train_kpca,y_train)
X_test_kpca = kpca.transform(X_test_std)
y_pred_kpca = tree_model.predict(X_test_kpca)
print("KPCA-shape for iris",X_train_kpca.shape)

#Accuracy
acc_score_kpca = accuracy_score(y_pred_kpca,y_test)
print("KPCA Accuracy for iris",acc_score_kpca)
#precision
print('Precision KPCA for iris: ',precision_score(y_test, y_pred_lda,average='weighted'))
#recall
print('Recall for KPCA for iris:',recall_score(y_test, y_pred_lda,average='macro'))
#f1 score
print('F1 Score KPCA for iris:',f1_score(y_test, y_pred_lda,average='macro'))
#metric
print(classification_report(y_test,y_pred_kpca))
end_time = time.time()
print('Time',start_time-end_time)